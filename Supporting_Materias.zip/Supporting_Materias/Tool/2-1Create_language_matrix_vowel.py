import os
import pandas as pd
import numpy as np
from pathlib import Path

# file path
script_dir = Path(__file__).parent
root_dir = script_dir.parent 
vowel_dir = root_dir / "Data" / "fitted_plane_vowel"
output_dir = root_dir / "Data"
mapping_file = root_dir / "Language_map.csv" 

# collect all fitting plane files
def collect_fitted_plane_files(root_dir):
    file_paths = []
    root_dir = Path(root_dir)
    if not root_dir.exists():
        return file_paths
    
    for file_path in root_dir.glob('**/*_fitted_plane.csv'):
        wordpair = file_path.parent.name
        wordpair = wordpair.replace('-', '/')
        full_path = str(file_path)
        file_paths.append((wordpair, full_path))
    
    return file_paths

# creat matrix
def create_language_matrix(files):
    all_languages = set()
    for _, file_path in files:
        try:
            df = pd.read_csv(file_path)
            all_languages.update(df['LanguageName'].unique())
        except Exception as e:
            pass
    all_languages = sorted(all_languages)
    
    wordpairs = sorted(set(wordpair for wordpair, _ in files))
    
    # initialize presence matrix with zeros
    matrix = np.zeros((len(all_languages), len(wordpairs)), dtype=int)
    matrix_df = pd.DataFrame(matrix, index=all_languages, columns=wordpairs)
    
    # fill presence values (1 = language has data for wordpair)
    for wordpair, file_path in files:
        try:
            df = pd.read_csv(file_path)
            languages_in_file = set(df['LanguageName'])
            for language in languages_in_file:
                if language in matrix_df.index:
                    matrix_df.loc[language, wordpair] = 1
        except Exception as e:
            pass
    
    matrix_df.index.name = "Language"
    return matrix_df

def apply_language_mapping(matrix_df, mapping_file):
    mapping_file = Path(mapping_file)
    if not mapping_file.exists():
        return matrix_df.reset_index().rename(columns={'index': 'Language'})
    
    # load and apply mapping
    mapping_df = pd.read_csv(mapping_file)
    mapping_dict = dict(zip(mapping_df['Language'], mapping_df['Real_Language']))
    mapped_df = matrix_df.reset_index()
    mapped_df['Language'] = mapped_df['Language'].map(mapping_dict).fillna(mapped_df['Language'])
    
    # handle duplicate languages by taking max value
    final_df = mapped_df.groupby('Language', as_index=False).max()
    return final_df

def sort_matrix(matrix_df):
    # defined wordpair order 
    wordpair_order = [
        "big/small", "high/low", "tall/short(height)", "deep/shallow",
        "long/short(length)", "thick(diameter)/thin(diameter)", 
        "thick(depth)/thin(depth)", "wide/narrow", "far/near"
    ]
    
    # defined language order
    language_order = [
        "Khams Tibetan", "Southern Pumi", "Wuding-Luquan Yi", "Northern Nisu", "Hani",
        "Honi", "Lisu", "Lahu", "Lahu Shi", "Naxi", "Narua", "Youle Jinuo", "Katso",
        "Southern Bai", "Central Bai", "Nusu", "Zauzou", "Nung (Myanmar)", 
        "Southern Jinghpaw", "Drung", "Zaiwa", "Longchuan Achang", 
        "Chuanqiandian Cluster Miao", "Diandongbei-Large Flowery Miao", "Kim Mun",
        "Bu-Nao Bunu", "Nong Zhuang", "Qiubei Zhuang", "Bouyei", "Tai Nüa", "Lü",
        "Parauk", "Lavia-Awalai-Damangnuo Awa", "Blang", "Samtao", "Ruching Palaung"
    ]
    
    # ensure DataFrame has 'Language' column
    if 'Language' not in matrix_df.columns:
        matrix_df = matrix_df.reset_index().rename(columns={'index': 'Language'})
    
    # filter and sort languages
    existing_languages = [lang for lang in language_order if lang in matrix_df['Language'].values]
    
    # convert to categorical for custom sorting
    matrix_df['Language'] = pd.Categorical(
        matrix_df['Language'], 
        categories=existing_languages, 
        ordered=True
    )
    
    matrix_df = matrix_df.sort_values('Language')
    
    # filter and sort wordpairs
    existing_wordpairs = [wp for wp in wordpair_order if wp in matrix_df.columns]
    
    # create final column order: Language + ordered wordpairs
    final_columns = ['Language'] + existing_wordpairs
    
    return matrix_df[final_columns]

def main():
    # ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    # collect ONLY vowel files
    vowel_files = collect_fitted_plane_files(vowel_dir)
    
    # create presence matrix for vowels
    vowel_matrix = create_language_matrix(vowel_files)
    
    # apply language name mapping
    vowel_matrix_mapped = apply_language_mapping(vowel_matrix, mapping_file)
    
    # sort matrix by defined orders
    vowel_matrix_sorted = sort_matrix(vowel_matrix_mapped)
    
    # save results
    vowel_output_path = output_dir / "vowel_fitting_matrix.csv"
    vowel_matrix_sorted.to_csv(vowel_output_path, index=False)

if __name__ == "__main__":
    main()
    
print("\nFinished")