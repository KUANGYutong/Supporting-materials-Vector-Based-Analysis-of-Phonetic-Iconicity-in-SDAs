"""
Purpose:
Visualize pre-processed language presence matrices as heatmaps with:
1. Main heatmap showing presence/absence
2. Top bar: word pair coverage across languages
3. Right bar: language coverage across word pairs

"""

import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import numpy as np
from pathlib import Path

# visualization settings
PRESENCE_COLOR = "#4575b4"    
ABSENCE_COLOR = "#e0f3f8"     
BAR_COLOR = "#e0f3f8"         
LINE_COLOR = "#4575b4"        

# file paths
script_dir = Path(__file__).parent
root_dir = script_dir.parent
input_path = root_dir / "Data"
output_path = root_dir / "Data"

def plot_combined_heatmap(df, title_prefix, output_path):
    # prepare matrix data (assumes correct ordering)
    df.set_index('Language', inplace=True)
    languages = df.index.tolist()
    features = df.columns.tolist()
    data = df.values
    
    # compute coverage statistics
    feature_sums = df.sum(axis=0)   # languages per word pair
    language_sums = df.sum(axis=1)  # word pairs per language
    
    # initialize figure with custom layout
    fig = plt.figure(figsize=(16, 16))
    gs = GridSpec(2, 2, 
                  width_ratios=[15, 2],  # heatmap vs right bar
                  height_ratios=[2, 15],  # top bar vs heatmap
                  wspace=0.05, hspace=0.05)
    fig.suptitle(f'{title_prefix}: Inliers vs. Outliers', 
                 fontsize=18, fontweight='bold', y=0.95)
    
    # main heatmap
    ax_heatmap = fig.add_subplot(gs[1, 0])
    cmap = plt.cm.colors.ListedColormap([ABSENCE_COLOR, PRESENCE_COLOR])
    im = ax_heatmap.imshow(data, cmap=cmap, aspect='auto', vmin=0, vmax=1)
    
    # annotate cells with values
    for i in range(len(languages)):
        for j in range(len(features)):
            value = data[i, j]
            text_color = 'white' if value == 1 else 'black'
            ax_heatmap.text(j, i, str(int(value)), 
                          ha='center', va='center', 
                          color=text_color, fontsize=10)

    ax_heatmap.set_xticks(np.arange(len(features)))
    ax_heatmap.set_xticklabels(features, rotation=45, ha='right', fontsize=10)
    ax_heatmap.set_yticks(np.arange(len(languages)))
    ax_heatmap.set_yticklabels(languages, fontsize=10)
    
    # top bar (word pair coverage)
    ax_feature = fig.add_subplot(gs[0, 0], sharex=ax_heatmap)
    bar_positions = np.arange(len(features))
    ax_feature.bar(bar_positions, feature_sums, color=BAR_COLOR, alpha=0.7)
    ax_feature.plot(bar_positions, feature_sums, 'o-', color=LINE_COLOR, 
                  linewidth=2, markersize=6)
    
    # format top bar
    for spine in ax_feature.spines.values():
        spine.set_visible(False)
    plt.setp(ax_feature.get_xticklabels(), visible=False)
    ax_feature.set_ylabel('Language', fontsize=10)
    ax_feature.set_ylim(0, 35)  # fixed scale for comparison
    ax_feature.yaxis.set_major_locator(plt.MultipleLocator(5))  
    ax_feature.tick_params(axis='y', labelsize=8)
    
    # right bar (language coverage)
    ax_language = fig.add_subplot(gs[1, 1], sharey=ax_heatmap)
    bar_positions = np.arange(len(languages))
    ax_language.barh(bar_positions, language_sums, color=BAR_COLOR, alpha=0.7)
    ax_language.plot(language_sums, bar_positions, 'o-', color=LINE_COLOR, 
                   linewidth=2, markersize=6)
    
    # format right bar
    for spine in ax_language.spines.values():
        spine.set_visible(False)
    ax_language.set_xlim(0, 10)  # fixed scale for comparison
    ax_language.xaxis.set_major_locator(plt.MultipleLocator(2))  
    plt.setp(ax_language.get_yticklabels(), visible=False)
    ax_language.set_xlabel('Wordpair', fontsize=10)
    ax_language.tick_params(axis='x', labelsize=8)
    
    # save high-resolution output
    plt.subplots_adjust(top=0.92)  
    output_file = output_path / f'{title_prefix.lower()}_combined_plot.png'
    plt.savefig(output_file, bbox_inches='tight', dpi=600)
    plt.close()
   
# generate visualizations
consonant_path = input_path / 'consonant_fitting_matrix.csv'
consonant_df = pd.read_csv(consonant_path)
plot_combined_heatmap(consonant_df, 'Consonant', output_path)

vowel_path = input_path / 'vowel_fitting_matrix.csv'
vowel_df = pd.read_csv(vowel_path)
plot_combined_heatmap(vowel_df, 'Vowel', output_path)

print("\nFinished")