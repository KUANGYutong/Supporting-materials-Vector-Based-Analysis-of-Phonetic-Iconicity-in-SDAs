"""
Purpose: Analyze phonetic feature contributions to 3D contrast planes.

Design:
1. Computes signed contributions (direction) and absolute contributions (magnitude)
2. Combines PCA feature weights with plane orientation vector
3. Performs global normalization preserving zero values and amplifying differences (0-2 range)
4. Outputs ranked feature importance for phonetic interpretation

Outputs:
1. Full ranked feature contributions
2. Feature importance threshold ratios 
3. Feature direction matrix (+/-/0)
"""

import pandas as pd
import numpy as np
from scipy.stats import pearsonr
import matplotlib.pyplot as plt
import seaborn as sns
import os

# load data
data_dir = os.path.join("..", "Data")
plane_df = pd.read_csv(os.path.join(data_dir, "refitted_plane_vowel", "plane_refitting_summary_vowel.csv"))
feature_df = pd.read_csv(os.path.join(data_dir, "PCA_feature_vowel_fitted.csv")) 
data_df = pd.read_csv(os.path.join(data_dir, "PCA_data_vowel_fitted.csv"))
feature_map_df = pd.read_csv(os.path.join("..", "Feature_map_vowel.csv")) 

# define analysis parameters
wordpair_order = [
    "big/small", "high/low", "tall/short(height)", "deep/shallow",
    "long/short(length)", "thick(diameter)/thin(diameter)", 
    "thick(depth)/thin(depth)", "wide/narrow", "far/near"
]
feature_order = [
    "V1_Advancement", "V1_Height", "V1_Rounding", "V1_Apical",
    "V2_Advancement", "V2_Height", "V2_Rounding", "V2_Apical",
    "V3_Advancement", "V3_Height", "V3_Rounding", "V3_Apical"
]

# map raw features to phonetic interpretations
feature_mapping = dict(zip(feature_map_df['Feature'], feature_map_df['Real_Feature']))

# process plane orientation cosines
cos_df = plane_df[["WordPair", "Cos_theta_x", "Cos_theta_y", "Cos_theta_z"]].copy()
cos_df.columns = ["WordPair", "cos_pc1", "cos_pc2", "cos_pc3"]
original_cos_df = cos_df.copy()  
cos_df[["cos_pc1", "cos_pc2", "cos_pc3"]] = cos_df[["cos_pc1", "cos_pc2", "cos_pc3"]].abs()

# reshape PCA feature data
wide_df = feature_df.pivot_table(
    index=["WordPair", "Feature"],
    columns="PC",
    values=["VarianceContribution", "RawWeight"],
    aggfunc="first"
)
wide_df.columns = [f"{col[1]}_{col[0]}" for col in wide_df.columns]
wide_df = wide_df.reset_index()

# merge datasets
merged_df = pd.merge(wide_df, cos_df, on="WordPair")
merged_df = pd.merge(merged_df, original_cos_df, on="WordPair", suffixes=('', '_original'))  

# calculate signed feature contribution (accounts for plane orientation)
merged_df["SignedContribution"] = (
    merged_df["PC1_VarianceContribution"] * merged_df["PC1_RawWeight"] * merged_df["cos_pc1_original"] +
    merged_df["PC2_VarianceContribution"] * merged_df["PC2_RawWeight"] * merged_df["cos_pc2_original"] +
    merged_df["PC3_VarianceContribution"] * merged_df["PC3_RawWeight"] * merged_df["cos_pc3_original"]
)

# calculate feature importance as absolute value of signed contribution
merged_df["Contribution"] = merged_df["SignedContribution"].abs()

# map phonetic feature names
merged_df['Feature'] = merged_df['Feature'].map(feature_mapping)

# calculate global threshold (1 time standard deviation)
def calculate_threshold(contributions, n_std=1):
    mean = contributions.mean()
    std = contributions.std()
    return mean + n_std * std

# calculate word-pair relative contribution (original method)
grouped = merged_df.groupby("WordPair")["Contribution"].transform("sum")
merged_df["RelativeContribution"] = merged_df["Contribution"] / grouped

# global normalization to [0,1] while preserving zero values
max_contribution = merged_df["Contribution"].max()
merged_df["GlobalNormalized"] = merged_df["Contribution"] / max_contribution

# amplify differences to [0,2] range while preserving zero values
# using a combination of power function and exponential for amplification
def amplify_difference(value):
    if value == 0:
        return 0.0
    else:
        # power transformation to amplify differences
        powered = np.power(value, 0.7)  
        
        # exponential transformation to amplify larger values
        amplified = 2 * (1 - np.exp(-2.5 * powered)) / (1 - np.exp(-2.5))
        
        return amplified

merged_df["AmplifiedContribution"] = merged_df["GlobalNormalized"].apply(amplify_difference)

# update threshold calculation to use amplified values
global_threshold = calculate_threshold(merged_df['AmplifiedContribution'], n_std=1)
merged_df['Global_Threshold_Ratio'] = merged_df['AmplifiedContribution'] / global_threshold

# determine feature directionality
tolerance = 1e-10
merged_df['Direction'] = np.select(
    [
        merged_df['SignedContribution'] > tolerance,
        merged_df['SignedContribution'] < -tolerance,
        abs(merged_df['SignedContribution']) <= tolerance
    ],
    ['+', '-', '0'],
    default='?'
)

order_mapping = {wordpair: idx for idx, wordpair in enumerate(wordpair_order)}


# save results
wide_threshold_df = merged_df.pivot_table(
    index='WordPair', columns='Feature', values='Global_Threshold_Ratio', aggfunc='first'
)
for feature in feature_order:
    if feature not in wide_threshold_df.columns:
        wide_threshold_df[feature] = 0
wide_threshold_df['sort_order'] = wide_threshold_df.index.map(order_mapping)
wide_threshold_df = wide_threshold_df.sort_values('sort_order').drop('sort_order', axis=1)
wide_threshold_df[feature_order].to_csv(os.path.join(data_dir, "PCA_Feature_importance_threshold_vowel_fitted.csv"))
wide_direction_df = merged_df.pivot_table(
    index='WordPair', columns='Feature', values='Direction', aggfunc='first'
)
for feature in feature_order:
    if feature not in wide_direction_df.columns:
        wide_direction_df[feature] = '0'
wide_direction_df['sort_order'] = wide_direction_df.index.map(order_mapping)
wide_direction_df = wide_direction_df.sort_values('sort_order').drop('sort_order', axis=1)
wide_direction_df = wide_direction_df[feature_order]
wide_direction_df.to_csv(os.path.join(data_dir, "PCA_Feature_direction_vowel_fitted.csv"))

mean_contribution_df = merged_df.groupby('WordPair')['RelativeContribution'].mean().reset_index()
mean_contribution_df.rename(columns={'RelativeContribution': 'mean_contribution'}, inplace=True)
mean_contribution_df['threshold_important'] = calculate_threshold(mean_contribution_df['mean_contribution'], n_std=1)
merged_df = pd.merge(merged_df, mean_contribution_df, on='WordPair')

merged_df['sort_order'] = merged_df['WordPair'].map(order_mapping)
merged_df = merged_df.sort_values(['sort_order', 'RelativeContribution'], ascending=[True, False]).drop('sort_order', axis=1)
merged_df.to_csv(
    os.path.join(data_dir, "PCA_Feature_importance_rank_vowel_fitted.csv"), index=False)

# check orthogonality
def check_pc_orthogonality(df):
    corr_matrix = np.zeros((3, 3))
    p_values = np.zeros((3, 3))
    for i, pc1 in enumerate(['PC1', 'PC2', 'PC3']):
        for j, pc2 in enumerate(['PC1', 'PC2', 'PC3']):
            if i <= j:
                r, p = pearsonr(df[pc1], df[pc2])
                corr_matrix[i, j] = corr_matrix[j, i] = r
                p_values[i, j] = p_values[j, i] = p
    return corr_matrix, p_values

for wordpair in wordpair_order:
    if wordpair in data_df['WordPair'].unique():
        subset = data_df[data_df['WordPair'] == wordpair]
        corr_matrix, _ = check_pc_orthogonality(subset)
        off_diag_max = max(abs(corr_matrix[0, 1]), abs(corr_matrix[0, 2]), abs(corr_matrix[1, 2]))

print("\nFinished")
