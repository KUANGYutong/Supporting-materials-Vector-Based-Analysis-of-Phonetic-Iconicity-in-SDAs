"""
Purpose: Perform PCA on contrast vectors to reduce dimensionality and analyze feature contributions.
Design:
1. Processes 12-dimensional phonetic difference vectors for each word pair
2. Computes top principal components per word pair
3. Quantifies feature importance in PCA space
Outputs:
1. PCA projections (PC1-3) for visualization
2. Feature contribution analysis for phonetic interpretation
"""

import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import os

# file paths
input_file = os.path.join("..", "Data", "WordPair_Vectors_data_consonant.csv")
output_pca_data = os.path.join("..", "Data", "PCA_data_consonant.csv")
output_pca_features = os.path.join("..", "Data", "PCA_feature_consonant.csv")

# load and clean data
df = pd.read_csv(input_file, header=0, index_col=0)
df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
df = df.replace("", np.nan)
df = df.dropna()

# maintain consistent word pair order for analysis
desired_order = [
    "big/small",
    "high/low",
    "tall/short(height)",
    "deep/shallow",
    "long/short(length)",
    "thick(diameter)/thin(diameter)",
    "thick(depth)/thin(depth)",
    "wide/narrow",
    "far/near"
]

existing_columns = [col for col in desired_order if col in df.columns]
df = df[existing_columns]

def parse_vector(cell):
    try:
        cell = str(cell)
        if cell.strip() == "":
            return np.zeros(12)
        vector = np.array([float(x.strip()) for x in cell.split(',')], dtype=float)
        if len(vector) != 12:
            print(f"Warning: the vector is {len(vector)}: {cell}")
            return np.zeros(12)
        return vector
    except Exception as e:
        print(f"Parse vector error: {e} - '{cell}'")
        return np.zeros(12)

# result containers
all_pca_results = []          # PCA projections
all_pc_contributions = []     # explained variance
all_feature_contributions = [] # feature weights

for col in df.columns:
    # parse and standardize vectors
    vectors = [parse_vector(df.loc[lang, col]) for lang in df.index]
    vectors = np.array(vectors)
    scaler = StandardScaler()
    scaled_vectors = scaler.fit_transform(vectors)
    
    # reduce to 3 principal components
    pca = PCA(n_components=3)
    pca_result = pca.fit_transform(scaled_vectors)
    
    # store PCA projections
    for i, lang in enumerate(df.index):
        all_pca_results.append({
            "Language": lang,
            "WordPair": col,
            "PC1": pca_result[i, 0],
            "PC2": pca_result[i, 1],
            "PC3": pca_result[i, 2]
        })
    
    # record variance explained
    variance_ratios = pca.explained_variance_ratio_
    for pc_idx, ratio in enumerate(variance_ratios):
        all_pc_contributions.append({
            "WordPair": col,
            "PC": f"PC{pc_idx+1}",
            "VarianceContribution": ratio
        })
    
    # clculate feature contributions to each PC
    components = pca.components_
    for pc_idx in range(3):
        pc_contribution = variance_ratios[pc_idx]
        weights = components[pc_idx]
        
        # normalized absolute weights = feature importance in PC
        abs_weights = np.abs(weights)
        feat_contrib_in_pc = abs_weights / np.sum(abs_weights)
        
        # total contribution = feature weight × PC variance
        feat_total_contribution = pc_contribution * feat_contrib_in_pc
        
        for feat_idx in range(12):
            all_feature_contributions.append({
                "WordPair": col,
                "PC": f"PC{pc_idx+1}",
                "Feature": f"F{feat_idx+1}",
                "RawWeight": weights[feat_idx],
                "FeatureContributionInPC": feat_contrib_in_pc[feat_idx],
                "TotalContribution": feat_total_contribution[feat_idx]
            })

# create and save DataFrames
pca_results_df = pd.DataFrame(all_pca_results)
pc_contributions_df = pd.DataFrame(all_pc_contributions)
feature_contributions_df = pd.DataFrame(all_feature_contributions)

# merge variance and feature data
feature_contributions_df = feature_contributions_df.sort_values(
    by=["WordPair", "PC", "TotalContribution"], 
    ascending=[True, True, False]
)

pca_results_df.to_csv(output_pca_data, index=False)

final_feature_df = pd.merge(
    pc_contributions_df,
    feature_contributions_df,
    on=["WordPair", "PC"],
    how="right"
)
final_feature_df.to_csv(output_pca_features, index=False)

print("\nFinished")