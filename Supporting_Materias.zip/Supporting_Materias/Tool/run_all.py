"""
Phonological Analysis Pipeline
Workflow Structure:
1. VOWEL BASIC PROCESSING:
   Feature counting → Initial PCA → Plane fitting
2. VOWEL FILTERED PROCESSING:
   Language matrix → Filtered PCA → Optimized plane fitting → Contribution analysis → Heatmap
3. CONSONANT BASIC PROCESSING:
   Feature counting → Initial PCA → Plane fitting
4. CONSONANT FILTERED PROCESSING:
   Language matrix → Filtered PCA → Optimized plane fitting → Contribution analysis → Heatmap
5. TRUSTWORTHINESS EVALUATION:
   Evaluate dimensionality reduction methods trustworthiness
   (In the actual operation, when selecting the data processing method, 
   the reliability of different dimension reduction methods will be evaluated after the word pair vector is obtained, 
   but in order to facilitate the repeated implementation of the workflow, it is placed here)
6. POST-PROCESSING:
   Spatial visualizations
"""

import subprocess
from pathlib import Path
from enum import Enum, auto
import time

class AnalysisType(Enum):
    VOWEL_BASIC = auto()
    VOWEL_FILTERED = auto()
    CONSONANT_BASIC = auto() 
    CONSONANT_FILTERED = auto()
    TRUSTWORTHINESS = auto()
    POST_PROCESS = auto()

class PipelineRunner:
    def __init__(self):
        self.script_dir = Path(__file__).parent.parent / "Tool"
        self.workflows = {
            AnalysisType.VOWEL_BASIC: [
                "1-1count_big-small_vowel.py",
                "1-2PCA_n_feature_vowel.py",
                "1-3Fitted_plane_vowel.py"
            ],
            AnalysisType.VOWEL_FILTERED: [
                "2-1Create_language_matrix_vowel.py",
                "2-2rePCA_n_feature_vowel.py",
                "2-3reFitted_plane_vowel.py",
                "2-4PCA_feature_contribution_vowel.py",
                "2-5Draw_heatmap_vowel.py"
            ],
            AnalysisType.CONSONANT_BASIC: [
                "3-1count_big-small_consonant.py",
                "3-2PCA_n_feature_consonant.py",
                "3-3Fitted_plane_consonant.py"
            ],
            AnalysisType.CONSONANT_FILTERED: [
                "4-1Create_language_matrix_consonant.py",
                "4-2rePCA_n_feature_consonant.py", 
                "4-3reFitted_plane_consonant.py",
                "4-4PCA_feature_contribution_consonant.py",
                "4-5Draw_heatmap_consonant.py"
            ],
            AnalysisType.TRUSTWORTHINESS: [
                "5Methods_trustworthiness.py"
            ],
            AnalysisType.POST_PROCESS: [
                "6Spatial_visualization.py"
            ]
        }

    # execute complete analysis workflow for a phonological category
    def _run_script(self, script_name: str) -> bool:
        start_time = time.time()
        try:
            result = subprocess.run(
                ["python", str(self.script_dir / script_name)],
                cwd=str(self.script_dir),
                check=True,
                text=True,
                capture_output=True
            )
            elapsed = time.time() - start_time
            success_msg = next(
                (line for line in result.stdout.split('\n') 
                if "Finished" in line or "complete" in line.lower()),
                "Executed successfully"
            )
            print(f"✓ {script_name:<35} ({elapsed:.1f}s) {success_msg[:50]}...")
            return True
        except subprocess.CalledProcessError as e:
            elapsed = time.time() - start_time
            error_msg = next(
                (line for line in e.stderr.split('\n') 
                if "error" in line.lower() or "fail" in line.lower()),
                e.stderr[:50] or "Unknown error"
            )
            print(f"✗ {script_name:<35} ({elapsed:.1f}s) {error_msg}")
            return False

    # main pipeline execution controller
    def execute(self):
        print("\n=== PHONOLOGICAL ANALYSIS PIPELINE ===")
        
        for stage in AnalysisType:
            print(f"\n▶ {stage.name.replace('_', ' ').title()}")
            for script in self.workflows[stage]:
                if not self._run_script(script):
                    print(f"\n! Pipeline terminated at {script}")
                    return
        
        print("\nCompleted")

if __name__ == "__main__":
    PipelineRunner().execute()