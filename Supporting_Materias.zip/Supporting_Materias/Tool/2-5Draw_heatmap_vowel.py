"""
Purpose: Visualize relative feature contributions across word pairs and highlight significant phonetic features using color coding
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap
import matplotlib as mpl
import os

# visualization Configuration
def set_custom_style():
    plt.rcParams.update({
        "font.sans-serif": ["Arial"],
        "axes.unicode_minus": False,
        "axes.edgecolor": "#333333",
        "axes.labelcolor": "#333333",
        "axes.titleweight": "bold",
        "axes.titlesize": 14,
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "grid.color": "#dddddd",
        "grid.linestyle": "-",
        "grid.linewidth": 1,
        "figure.dpi": 600,
        "savefig.transparent": False,
        "savefig.bbox": "tight"
    })

# initialize style configuration
set_custom_style() 

# load thresholded feature importance data
data_path = os.path.join("..", "Data", "PCA_Feature_importance_threshold_vowel_fitted.csv")
df = pd.read_csv(data_path, index_col='WordPair')
df = df.applymap(lambda x: float(x) if isinstance(x, str) else x)
df = df.applymap(lambda x: 0.0 if abs(x) < 1e-10 else x)

# create diverging colormap (blue → white → red)
colors = ["#4575b4", "#91bfdb", "#e0f3f8", "#ffffbf", "#fee090", "#fc8d59", "#d73027"]
cmap = LinearSegmentedColormap.from_list("custom_diverging", colors, N=256)

# initialization figure 
fig, ax = plt.subplots(figsize=(16, 10))

# create heatmap
cax = ax.imshow(
    df.values.astype(float),
    cmap=cmap, 
    aspect='auto',
    vmin=0, 
    vmax=1.5   
)

ax.set_xticks(np.arange(df.shape[1] + 1) - 0.5, minor=True)
ax.set_yticks(np.arange(df.shape[0] + 1) - 0.5, minor=True)
ax.grid(which="minor", color="white", linestyle="-", linewidth=1)
ax.tick_params(which="minor", length=0)
ax.set_xticks(np.arange(df.shape[1]))
ax.set_yticks(np.arange(df.shape[0]))
ax.set_xticklabels(df.columns, rotation=45, ha="right", rotation_mode="anchor")
ax.set_yticklabels(df.index)

# annotate cell value annotation
for i in range(df.shape[0]):     # iterate through rows (word pairs)
    for j in range(df.shape[1]): # iterate through columns (features)
        value = df.iat[i, j]
        rgba = cmap((value - 0) / (1.6 - 0))
        brightness = 0.299 * rgba[0] + 0.587 * rgba[1] + 0.114 * rgba[2]
        text_color = "black" if brightness > 0.6 else "white"
        fontweight = "bold" if value >= 1.0 else "normal"
        
        ax.text(
            j, i, 
            f"{value:.2f}",
            ha="center", 
            va="center",
            color=text_color,
            fontsize=9,
            fontweight=fontweight
        )

# configurate colorbar 
cbar = fig.colorbar(
    cax, 
    ax=ax, 
    pad=0.02, 
    aspect=40,
    shrink=0.8
)
cbar.set_label("Relative Contribution (Threshold_Ratio)", fontsize=11)
cbar.set_ticks(np.arange(0, 1.6, 0.5)) 

# add labels and titles
ax.set_title(
    "Vowel: Relative Contribution",
    fontsize=14,
    pad=20
)
ax.set_xlabel("Phonetic Features", fontsize=12, labelpad=15)
ax.set_ylabel("Word Pairs", fontsize=12, labelpad=15)

# output generation
plt.tight_layout(pad=2.0)

output_path = os.path.join("..", "Data", "Feature_Importance_Heatmap_vowel.png")

plt.savefig(output_path)
plt.close()

print("\nFinished")