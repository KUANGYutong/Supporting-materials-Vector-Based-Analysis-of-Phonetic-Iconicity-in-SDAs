"""
Fit planes to 3D PCA projections of contrasts and assess planarity:
1. Uses RANSAC for robust plane fitting to handle phonetic data outliers
2. Computes planarity metrics and quality scores for phonetic interpretation
3. Generates visualizations of fitted planes with distance metrics
Outputs:
1. Plane equations and normal vectors
2. Planarity quality assessments
3. 3D visualizations with distance-to-plane coloring
4. Direction cosines of normal vectors
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from mpl_toolkits.mplot3d import Axes3D
from sklearn.linear_model import RANSACRegressor
from sklearn.preprocessing import StandardScaler
import os
import warnings

# set global random seed for reproducibility
np.random.seed(42)

# configure consistent plot styling
def set_default_style():
    plt.rcParams["font.sans-serif"] = ["Arial"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["axes.edgecolor"] = "#ffffff"
    plt.rcParams["axes.grid"] = True
    plt.rcParams["grid.color"] = "#dcdcdc"
    plt.rcParams["grid.linestyle"] = "--"
    plt.rcParams["legend.fontsize"] = 10

# calculate Euclidean distance from points to plane
def point_to_plane_distance(points, a, b, c):
    normal = np.array([a, b, -1.0])
    norm = np.linalg.norm(normal)
    return np.abs(a*points[:,0] + b*points[:,1] - points[:,2] + c) / norm

# compute planarity as standard deviation of distances
def compute_planarity_measure(points, a, b, c):
    distances = point_to_plane_distance(points, a, b, c)
    return np.std(distances), distances

# calculate quality score and tier (Perfect/Good/Decent)
def compute_quality_score(planarity_measure, dynamic_threshold):
    rps = np.exp(-planarity_measure / dynamic_threshold)
    tier = 'Perfect' if rps >= 0.85 else 'Good' if rps >= 0.6 else 'Decent'
    return rps, tier

# load PCA data and prepare output
file_path = os.path.join("..", "Data", "PCA_data_vowel.csv")
df = pd.read_csv(file_path)
output_dir = os.path.join("..", "Data", "fitted_plane_vowel")
os.makedirs(output_dir, exist_ok=True)
summary_results = []

# process each word pair separately
for wordpair, group in df.groupby('WordPair'):
    safe_wordpair = wordpair.replace("/", "-").replace(" ", "_")
    group_dir = os.path.join(output_dir, safe_wordpair)
    os.makedirs(group_dir, exist_ok=True)
    
    # extract PCA coordinates
    X_orig = group['PC1'].values
    Y_orig = group['PC2'].values
    Z_orig = group['PC3'].values
    languages = group['Language'].values

    data_orig = np.vstack([X_orig, Y_orig, Z_orig]).T
    
    try:
        # standardize data for consistent plane fitting
        scaler = StandardScaler()
        data_scaled = scaler.fit_transform(data_orig)
        scaling_params = {
            'mean': scaler.mean_,
            'scale': scaler.scale_
        }
        np.save(os.path.join(group_dir, f"{safe_wordpair}_scaling_params.npy"), scaling_params)
        
        # fit plane using RANSAC (robust to phonetic outliers)
        def fit_plane_ransac(data, random_seed=None):
            X = data[:, :2]  
            Z = data[:, 2]   
            ransac = RANSACRegressor(random_state=random_seed, min_samples=3)
            ransac.fit(X, Z)
            coefficients = ransac.estimator_.coef_
            intercept = ransac.estimator_.intercept_
            return coefficients, intercept, ransac

        # remove outliers using MAD-based threshold
        def remove_outliers(data, ransac, threshold=1.5, max_outliers_ratio=0.3):
            X = data[:, :2]
            Z = data[:, 2]
            predicted_Z = ransac.predict(X)
            residuals = Z - predicted_Z
            median_residual = np.median(residuals)
            mad = np.median(np.abs(residuals - median_residual))
            std_residual = 1.4826 * mad
            mask = np.abs(residuals) < threshold * std_residual
            outliers_ratio = 1 - np.mean(mask)
            
            if outliers_ratio > max_outliers_ratio:
                new_threshold = np.percentile(np.abs(residuals), 100*(1-max_outliers_ratio))
                mask = np.abs(residuals) < new_threshold
                outliers_ratio = 1 - np.mean(mask)
            return data[mask], outliers_ratio, mask

        # set fixed random seed
        random_seed = 42
        
        # initial plane fit
        coefficients_scaled, intercept_scaled, ransac = fit_plane_ransac(data_scaled, random_seed=random_seed)
        a_scaled, b_scaled = coefficients_scaled
        c_scaled = intercept_scaled
        
        # calculate initial planarity
        planarity_measure, errors = compute_planarity_measure(data_scaled, a_scaled, b_scaled, c_scaled)
        
        # remove outliers
        data_no_outliers_scaled, outliers_ratio, mask = remove_outliers(data_scaled, ransac)
        
        # refit plane without outliers
        coefficients_no_outliers_scaled, intercept_no_outliers_scaled, ransac_no_outliers = fit_plane_ransac(
            data_no_outliers_scaled, random_seed=random_seed)
        a_no_outliers_scaled, b_no_outliers_scaled = coefficients_no_outliers_scaled
        c_no_outliers_scaled = intercept_no_outliers_scaled
        
        # calculate final planarity
        planarity_measure_no_outliers, errors_no_outliers = compute_planarity_measure(
            data_no_outliers_scaled, a_no_outliers_scaled, b_no_outliers_scaled, c_no_outliers_scaled)
        
        # convert plane coefficients to original space
        mean_x, mean_y, mean_z = scaler.mean_
        scale_x, scale_y, scale_z = scaler.scale_
       
       # transform plane back to original space
        a_orig = a_no_outliers_scaled * (scale_z / scale_x)
        b_orig = b_no_outliers_scaled * (scale_z / scale_y)
        c_orig = c_no_outliers_scaled * scale_z + mean_z - a_orig * mean_x - b_orig * mean_y
        
        # ensure consistent normal vector direction
        normal_vector = np.array([a_orig, b_orig, -1.0])
        original_normal = normal_vector.copy()
        
        centroid = np.mean(data_scaled, axis=0)
        direction_vector = centroid - np.array([0,0,0])
        if np.dot(normal_vector, direction_vector) < 0:
            normal_vector = -normal_vector
            a_orig = -a_orig
            b_orig = -b_orig
            c_orig = -c_orig
        
        normal_magnitude = np.linalg.norm(normal_vector)
        normal_unit = normal_vector / normal_magnitude
        
        # calculate angles with principal axes
        cos_theta_x = abs(np.dot(normal_unit, [1, 0, 0]))
        cos_theta_y = abs(np.dot(normal_unit, [0, 1, 0]))
        cos_theta_z = abs(np.dot(normal_unit, [0, 0, 1]))
        
        angle_x = np.degrees(np.arccos(cos_theta_x))
        angle_y = np.degrees(np.arccos(cos_theta_y))
        angle_z = np.degrees(np.arccos(cos_theta_z))
        
        # dynamic planarity threshold
        scale_factor = np.max(scaler.scale_)
        dynamic_threshold = 0.05 * scale_factor
        
        # Calculate quality metrics
        quality_score, quality_tier = compute_quality_score(planarity_measure_no_outliers, dynamic_threshold)
        
        # plane equation string
        equation = f"Z = {a_orig:.6f}*X + {b_orig:.6f}*Y + {c_orig:.6f}"
        
        # convert scaled data back to original space
        original_data_no_outliers = data_no_outliers_scaled * scaler.scale_ + scaler.mean_
        X_no_outliers = original_data_no_outliers[:, 0]
        Y_no_outliers = original_data_no_outliers[:, 1]
        Z_no_outliers = original_data_no_outliers[:, 2]
        
        # get corresponding language names
        languages_no_outliers = languages[mask]
        
        # calculate distances in original space
        points_orig = np.column_stack((X_no_outliers, Y_no_outliers, Z_no_outliers))
        distances_orig = point_to_plane_distance(points_orig, a_orig, b_orig, c_orig)
        
        # prepare results and save
        output_df = pd.DataFrame({
            'LanguageName': languages_no_outliers,
            'Original_PC1': X_no_outliers,
            'Original_PC2': Y_no_outliers,
            'Original_PC3': Z_no_outliers,
            'Distance_to_Plane': distances_orig,
            'Normal_X': original_normal[0],
            'Normal_Y': original_normal[1],
            'Normal_Z': original_normal[2]
        })
        
        csv_path = os.path.join(group_dir, f"{safe_wordpair}_fitted_plane.csv")
        output_df.to_csv(csv_path, index=False)
        
        # save equation and metrics
        equation_path = os.path.join(group_dir, f"{safe_wordpair}_equation_and_angles.txt")
        with open(equation_path, 'w') as f:
            f.write(f"=== Plane Equation ===\n{equation}\n\n")
            f.write(f"=== Normal Vector ===\nNormal Vector: ({normal_vector[0]:.6f}, {normal_vector[1]:.6f}, {normal_vector[2]:.6f})\n")
            f.write(f"Original Normal Vector: ({original_normal[0]:.6f}, {original_normal[1]:.6f}, {original_normal[2]:.6f})\n\n")
            f.write(f"=== Quality Metrics ===\n")
            f.write(f"Planarity measure (std of distances): {planarity_measure_no_outliers:.6f}\n")
            f.write(f"Dynamic threshold: {dynamic_threshold:.6f}\n")
            f.write(f"Quality Score (RPS): {quality_score:.6f}\n")
            f.write(f"Quality Tier: {quality_tier}\n")
            f.write(f"Outliers ratio: {outliers_ratio:.4f}\n")
        
        # store summary results
        summary_results.append({
            'WordPair': wordpair,
            'Equation': equation,
            'Coefficient_X': a_orig,
            'Coefficient_Y': b_orig,
            'Intercept': c_orig,
            'Normal_X': normal_vector[0],
            'Normal_Y': normal_vector[1],
            'Normal_Z': normal_vector[2],
            'Original_Normal_X': original_normal[0],
            'Original_Normal_Y': original_normal[1],
            'Original_Normal_Z': original_normal[2],
            'Cos_theta_x': cos_theta_x,
            'Cos_theta_y': cos_theta_y,
            'Cos_theta_z': cos_theta_z,
            'Angle_x_deg': angle_x,
            'Angle_y_deg': angle_y,
            'Angle_z_deg': angle_z,
            'Planarity_Measure': planarity_measure_no_outliers,
            'Dynamic_Threshold': dynamic_threshold,
            'Quality_Score': quality_score,
            'Quality_Tier': quality_tier,
            'Outliers_Number': len(group) - len(data_no_outliers_scaled)         
        })

        # visualization
        colors = ["#4575b4", "#91bfdb", "#e0f3f8", "#ffffbf", "#fee090", "#fc8d59", "#d73027"]
        custom_cmap = LinearSegmentedColormap.from_list("custom_diverging", colors, N=256)
        
        fig = plt.figure(figsize=(12, 9))
        ax = fig.add_subplot(111, projection='3d')
        
        sc = ax.scatter(X_no_outliers, Y_no_outliers, Z_no_outliers, 
                s=60, c=distances_orig, cmap=custom_cmap, 
                vmin=0, vmax=4, label='Fitted Points', alpha=0.8)

        cbar = fig.colorbar(sc, ax=ax, shrink=0.6, pad=0.12)
        cbar.set_label('Distance to Plane', fontname='Arial', fontsize=10)
        cbar.set_ticks(np.arange(0, 4, 0.5))
        
        # add plane and normal vector
        centroid = np.mean(original_data_no_outliers, axis=0)
        normal_unit = normal_vector / np.linalg.norm(normal_vector)
        fixed_length = 6
        ax.quiver(centroid[0], centroid[1], centroid[2],
                   normal_unit[0], normal_unit[1], normal_unit[2],
                   length=fixed_length, color='red',
                   arrow_length_ratio=0.2, linewidth=2, label='Plane Normal')
        
        # generate plane surface
        x_min, x_max = np.min(X_no_outliers), np.max(X_no_outliers)
        y_min, y_max = np.min(Y_no_outliers), np.max(Y_no_outliers)
        x_fit = np.linspace(x_min, x_max, 30)
        y_fit = np.linspace(y_min, y_max, 30)
        x_fit, y_fit = np.meshgrid(x_fit, y_fit)
        z_fit = a_orig * x_fit + b_orig * y_fit + c_orig
        
        ax.plot_surface(x_fit, y_fit, z_fit, color='lightblue', alpha=0.4, label='Fitted Plane')
        
        # configure plot
        ax.set_xlabel('PC1', fontname='Arial', fontsize=11, labelpad=10)
        ax.set_ylabel('PC2', fontname='Arial', fontsize=11, labelpad=10)
        ax.set_zlabel('PC3', fontname='Arial', fontsize=11, labelpad=10)
        ax.zaxis.set_rotate_label(False)  
        ax.set_xlim(-6, 9)
        ax.set_xticks(np.arange(-6, 10, 2))
        ax.set_ylim(-4, 7)
        ax.set_yticks(np.arange(-4, 8, 2))
        ax.set_zlim(-19, 39)
        ax.set_zticks(np.arange(-20, 40, 10))
        title = f'Fitted Plane for "{wordpair}"\n{equation}\nQuality: {quality_tier}'
        ax.set_title(title, fontname='Arial', fontsize=12, pad=20)
        ax.legend(loc='upper right', fontsize=9)
        ax.view_init(elev=20, azim=-60)
        
        # save figure
        img_path = os.path.join(group_dir, f"{safe_wordpair}_fitted_plane.png")
        plt.savefig(img_path, dpi=600, bbox_inches='tight')
        plt.close()
    
    except Exception as e:
        print(f"Error processing {wordpair}: {str(e)}")
        summary_results.append({
            'WordPair': wordpair,
            'Error': str(e)
        })

# save summary
if summary_results:
    summary_df = pd.DataFrame(summary_results)
    summary_path = os.path.join(output_dir, "plane_fitting_summary_vowel.csv")
    summary_df.to_csv(summary_path, index=False)

print("\nFinished")