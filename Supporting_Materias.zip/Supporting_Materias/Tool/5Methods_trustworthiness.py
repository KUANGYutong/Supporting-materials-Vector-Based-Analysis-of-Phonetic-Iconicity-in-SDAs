"""
Purpose: 
Evaluates the trustworthiness of various dimensionality reduction methods(PCA, t-SNE, UMAP, LLE, Isomap, MDS, Spectral Embedding) on word pair vector data.
It processes both vowel and consonant datasets separately, calculates trustworthiness scores,and saves the results to Excel files.
Input: WordPair_Vectors_data_vowel.csv, WordPair_Vectors_data_consonant.csv
Output: Excel files with trustworthiness scores and reduced dimensions for each method and word pair.
"""

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.manifold import (TSNE, LocallyLinearEmbedding, 
                             Isomap, MDS, SpectralEmbedding, trustworthiness)
import umap
import os
import re

# load CSV data (with L2 normalization)
def load_wordpair_data(file_path):
    df = pd.read_csv(file_path)
    languages = df.iloc[:, 0].tolist()
    wordpairs = df.columns[1:].tolist()
    
    wordpair_data = {}
    for wp in wordpairs:
        vectors = []
        for vec_str in df[wp]:
            cleaned = re.sub(r'["\']', '', vec_str)
            vec = np.array(list(map(float, cleaned.split(','))))
            norm = np.linalg.norm(vec)
            if norm > 0:
                vec = vec / norm
            vectors.append(vec)
        wordpair_data[wp] = np.array(vectors)
    
    return languages, wordpairs, wordpair_data

# dynamically calculate optimal number of neighbors
def get_optimal_k(n_samples):
    if n_samples <= 10: return 3
    if n_samples <= 20: return 5
    return min(10, n_samples//2)

# trustworthiness calculation with retry mechanism
def compute_trust_with_retry(X, X_red, method, k, n_retries=3):
    if method in ['tSNE', 'UMAP']:
        trusts = []
        for _ in range(n_retries):
            if method == 'tSNE':
                model = TSNE(n_components=3, 
                            perplexity=max(3, min(30, len(X)//3)),
                            early_exaggeration=12,
                            learning_rate='auto',
                            n_iter=2000,
                            random_state=42)
            else:
                model = umap.UMAP(n_components=3,
                                n_neighbors=k,
                                min_dist=0.1,
                                metric='cosine',
                                random_state=None,
                                n_jobs=-1)
            trusts.append(trustworthiness(X, model.fit_transform(X), n_neighbors=k))
        return np.mean(trusts)
    return trustworthiness(X, X_red, n_neighbors=k)

# main processing function
def process_wordpairs(wordpair_data, output_dir, data_type, languages):
    results = {}
    
    for wp_name, vectors in wordpair_data.items():
        X = vectors
        k = get_optimal_k(len(X))
        
        # initialize dimensionality reduction methods
        methods = {
            'PCA': PCA(n_components=3).fit_transform(X),
            'tSNE': TSNE(
                n_components=3,
                perplexity=max(3, min(30, len(X)//3)),
                early_exaggeration=12,
                learning_rate='auto',
                n_iter=2000,
                random_state=42
            ).fit_transform(X),
            'LLE': LocallyLinearEmbedding(
                n_components=3,
                n_neighbors=k,
                random_state=42
            ).fit_transform(X),
            'Isomap': Isomap(
                n_components=3,
                n_neighbors=k
            ).fit_transform(X),
            'UMAP': umap.UMAP(
                n_components=3,
                n_neighbors=k,
                min_dist=0.1,
                metric='cosine',
                random_state=None,
                n_jobs=-1
            ).fit_transform(X),
            'MDS': MDS(
                n_components=3, 
                normalized_stress='auto',
                random_state=42
            ).fit_transform(X),
            'Spectral': SpectralEmbedding(
                n_components=3,
                n_neighbors=k,
                random_state=42
            ).fit_transform(X)
        }
        
        # calculate trustworthiness
        trusts = {}
        for name, X_red in methods.items():
            trusts[name] = compute_trust_with_retry(X, X_red, name, k)
        
        # store results
        results[wp_name] = {
            'methods': methods,
            'trusts': trusts
        }
        
        # save results
        safe_wp_name = re.sub(r'[/()]', '_', wp_name)
        output_path = os.path.join(output_dir, f"{data_type}_trustworthiness_{safe_wp_name}.xlsx")
        with pd.ExcelWriter(output_path, engine='xlsxwriter') as writer:
            for method_name, coords in methods.items():
                df = pd.DataFrame(coords, columns=[f'{method_name}1', f'{method_name}2', f'{method_name}3'])
                df.insert(0, 'Language', languages)
                df.to_excel(writer, sheet_name=method_name, index=False)
                worksheet = writer.sheets[method_name]
                worksheet.write(0, 5, 'Trustworthiness:')
                worksheet.write(0, 6, trusts[method_name])
    
    return results

def main():
    # configure paths using relative paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    input_dir = os.path.join(script_dir, "..", "Data")
    output_dir = os.path.join(script_dir, "..", "Data", "trustworthiness")
    
    # create output directory
    os.makedirs(output_dir, exist_ok=True)

    # process vowel and consonant data
    data_types = {
        'vowel': 'WordPair_Vectors_data_vowel.csv',
        'consonant': 'WordPair_Vectors_data_consonant.csv'
    }

    for data_type, filename in data_types.items():
        input_csv = os.path.join(input_dir, filename)
        print(f"\nProcessing {data_type} data: {input_csv}")
        
        # load data
        languages, wordpairs, wordpair_data = load_wordpair_data(input_csv)
        print(f"Loaded {len(wordpairs)} word pairs")
        
        # process all word pairs
        results = process_wordpairs(wordpair_data, output_dir, data_type, languages)
        
        # generate trustworthiness summary table
        trust_summary = []
        for wp, data in results.items():
            row = {'Word Pair': wp}
            row.update(data['trusts'])
            trust_summary.append(row)
        trust_df = pd.DataFrame(trust_summary)
        output_xlsx = os.path.join(output_dir, f"{data_type}_trustworthiness_combined.xlsx")
        trust_df.to_excel(output_xlsx, index=False) 

    print("\nFinished")

if __name__ == "__main__":
    main()