"""
Purpose: Process vector data to compute phonetic contrast differences between word pairs.
Design:
1. Reads consonant vector data
2. Processes 18 vector columns (9 word pairs) by extracting only first 12 elements (core formant features) and calculating element-wise differences between paired vectors
3. Outputs results to WordPair_Vectors_data_consonant.csv with original language/word pair identifiers and compact difference vectors for all 9 word pairs
"""

import pandas as pd
import os

# file paths
input_file = os.path.join("..", "Origin_Vectors_data_consonant.csv")
output_path = os.path.join("..", "Data", "WordPair_Vectors_data_consonant.csv")
os.makedirs(os.path.dirname(output_path), exist_ok=True)

# load and preprocess data
df = pd.read_csv(input_file)

def process_vector(vector_str):
    if isinstance(vector_str, str): 
        vector = vector_str.replace(" ", "").split(',')
        vector = [float(x) for x in vector if x != '']
        return vector[:12]
    else:
        return []

# process all consonant vector columns
for col in df.columns[1:19]:  
    df[col] = df[col].apply(process_vector)

# initialize result dataframe
result_df = pd.DataFrame()
result_df['Language\Word pair'] = df['Language\Word pair']

# compute pairwise differences
pair_names = []  
for i in range(1, 19, 2):  
    col_name1 = df.columns[i]
    col_name2 = df.columns[i+1]
    pair_name = f"{col_name1}/{col_name2}"
    pair_names.append(pair_name)
    col1 = df[col_name1]
    col2 = df[col_name2]
    diff_list = []
    for idx in range(len(df)):
        a = col1[idx]
        b = col2[idx]
        
        if isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
            formatted_diff = []
            for x, y in zip(a, b):
                diff_val = round(x - y, 1)
                if diff_val.is_integer():
                    formatted_diff.append(str(int(diff_val)))
                else:
                    formatted_diff.append(str(diff_val))
            diff_list.append(','.join(formatted_diff))
        else:
            diff_list.append('')  
    
    result_df[pair_name] = diff_list

# save results
result_df.to_csv(output_path, index=False)

print("\nFinished")