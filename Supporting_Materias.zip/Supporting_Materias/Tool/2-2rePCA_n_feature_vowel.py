"""
Modified Purpose: Perform PCA only on languages marked as 'fitted' (1) in vowel_fitting_matrix.csv
Design:
1. Load language mapping and fitting matrix
2. For each word pair, select only languages with fitting value=1
3. Perform PCA on 12-dimensional phonetic vectors for selected languages
4. Compute feature contributions
Outputs:
1. PCA projections (PC1-3) for visualization (fitted languages only)
2. Feature contribution analysis for phonetic interpretation
"""

import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import os

# file paths
input_vector_file = os.path.join("..", "Data", "WordPair_Vectors_data_vowel.csv")
fitting_matrix_file = os.path.join("..", "Data", "vowel_fitting_matrix.csv")
language_map_file = os.path.join("..", "Language_map.csv") 
output_pca_data = os.path.join("..", "Data", "PCA_data_vowel_fitted.csv")
output_pca_features = os.path.join("..", "Data", "PCA_feature_vowel_fitted.csv")

# load language mapping
language_map_df = pd.read_csv(language_map_file)
language_mapping = dict(zip(language_map_df["Real_Language"], language_map_df["Language"]))

# load fitting matrix
fitting_matrix = pd.read_csv(fitting_matrix_file)
fitting_matrix = fitting_matrix.set_index("Language")

# load and clean vector data
vector_df = pd.read_csv(input_vector_file, header=0, index_col=0)
vector_df = vector_df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
vector_df = vector_df.replace("", np.nan)
vector_df = vector_df.dropna()

# maintain consistent word pair order
desired_order = [
    "big/small",
    "high/low",
    "tall/short(height)",
    "deep/shallow",
    "long/short(length)",
    "thick(diameter)/thin(diameter)",
    "thick(depth)/thin(depth)",
    "wide/narrow",
    "far/near"
]

# filter only existing columns
existing_columns = [col for col in desired_order if col in vector_df.columns]
vector_df = vector_df[existing_columns]

def parse_vector(cell):
    try:
        cell = str(cell)
        if cell.strip() == "":
            return np.zeros(12)
        vector = np.array([float(x.strip()) for x in cell.split(',')], dtype=float)
        if len(vector) != 12:
            print(f"Warning: the vector is {len(vector)}: {cell}")
            return np.zeros(12)
        return vector
    except Exception as e:
        print(f"Parse vector error: {e} - '{cell}'")
        return np.zeros(12)

# result containers
all_pca_results = []          # PCA projections
all_pc_contributions = []     # explained variance
all_feature_contributions = [] # feature weights

# process each word pair
for word_pair in existing_columns:
    # get languages with fitting=1 for this word pair
    fitted_languages = []
    for lang_name in fitting_matrix.index:
        if fitting_matrix.loc[lang_name, word_pair] == 1:
            lang_code = language_mapping.get(lang_name)
            if lang_code and lang_code in vector_df.index:
                fitted_languages.append(lang_code)
    
    if not fitted_languages:
        print(f"No fitted languages found for {word_pair}, skipping")
        continue
    
    # parse vectors for selected languages
    vectors = []
    valid_languages = []
    for lang in fitted_languages:
        vec = parse_vector(vector_df.loc[lang, word_pair])
        vectors.append(vec)
        valid_languages.append(lang)
    
    vectors = np.array(vectors)
    
    # skip if not enough samples
    if len(vectors) < 2:
        print(f"Not enough samples for {word_pair} ({len(vectors)}), skipping")
        continue
    
    # standardize and apply PCA
    scaler = StandardScaler()
    scaled_vectors = scaler.fit_transform(vectors)
    pca = PCA(n_components=3)
    pca_result = pca.fit_transform(scaled_vectors)
    
    # store PCA projections
    for i, lang in enumerate(valid_languages):
        all_pca_results.append({
            "Language": lang,
            "WordPair": word_pair,
            "PC1": pca_result[i, 0],
            "PC2": pca_result[i, 1],
            "PC3": pca_result[i, 2]
        })
    
    # record variance explained
    variance_ratios = pca.explained_variance_ratio_
    for pc_idx, ratio in enumerate(variance_ratios):
        all_pc_contributions.append({
            "WordPair": word_pair,
            "PC": f"PC{pc_idx+1}",
            "VarianceContribution": ratio
        })
    
    # calculate feature contributions
    components = pca.components_
    for pc_idx in range(min(3, len(components))):
        pc_contribution = variance_ratios[pc_idx]
        weights = components[pc_idx]
        
        # normalized absolute weights = feature importance in PC
        abs_weights = np.abs(weights)
        feat_contrib_in_pc = abs_weights / np.sum(abs_weights)
        
        # total contribution = feature weight × PC variance
        feat_total_contribution = pc_contribution * feat_contrib_in_pc
        
        for feat_idx in range(12):
            all_feature_contributions.append({
                "WordPair": word_pair,
                "PC": f"PC{pc_idx+1}",
                "Feature": f"F{feat_idx+1}",
                "RawWeight": weights[feat_idx],
                "FeatureContributionInPC": feat_contrib_in_pc[feat_idx],
                "TotalContribution": feat_total_contribution[feat_idx]
            })

# create and save DataFrames
if all_pca_results:
    pca_results_df = pd.DataFrame(all_pca_results)
    pca_results_df.to_csv(output_pca_data, index=False)
else:
    print("No PCA results to save")

if all_pc_contributions and all_feature_contributions:
    pc_contributions_df = pd.DataFrame(all_pc_contributions)
    feature_contributions_df = pd.DataFrame(all_feature_contributions)
    
    # merge variance and feature data
    feature_contributions_df = feature_contributions_df.sort_values(
        by=["WordPair", "PC", "TotalContribution"], 
        ascending=[True, True, False]
    )
    
    final_feature_df = pd.merge(
        pc_contributions_df,
        feature_contributions_df,
        on=["WordPair", "PC"],
        how="right"
    )
    final_feature_df.to_csv(output_pca_features, index=False)
else:
    print("No feature contributions to save")

print("\nFinished")